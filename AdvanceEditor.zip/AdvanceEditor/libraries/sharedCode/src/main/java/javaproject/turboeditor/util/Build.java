package javaproject.turboeditor.util;

import sharedcode.turboeditor.BuildConfig;

public final class Build {

    public static final boolean DEBUG = BuildConfig.DEBUG;

    public static final String SUPPORT_EMAIL = "joeronxy@gmail.com";

    public static final String GOOGLE_PLAY_PUBLIC_KEY = "";

    public static final int MAX_FILE_SIZE = 20_000;

    public static final boolean FOR_AMAZON = false;

    public static class Links {

        public static final String GITHUB = "";

        public static final String XDA = "";

        public static final String TRANSLATE = "";

        public static final String DONATE = "";

        public static final String GOOGLE_PLUS_COMMUNITY = "";

        public static final String AMAZON_STORE = "";

        public static final String PLAY_STORE = "";

    }

}
