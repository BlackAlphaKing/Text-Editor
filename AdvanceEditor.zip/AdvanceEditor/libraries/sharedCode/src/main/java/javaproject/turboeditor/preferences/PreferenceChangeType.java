package javaproject.turboeditor.preferences;

public enum PreferenceChangeType {
            FONT_SIZE, ENCODING, SYNTAX, WRAP_CONTENT, MONOSPACE, LINE_NUMERS, THEME_CHANGE, TEXT_SUGGESTIONS, READ_ONLY, ACCESSORY_VIEW
 }