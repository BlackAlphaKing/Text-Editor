package javaproject.turboeditor.util;

public interface IHomeActivity {
    public abstract boolean showInterstitial();
}
