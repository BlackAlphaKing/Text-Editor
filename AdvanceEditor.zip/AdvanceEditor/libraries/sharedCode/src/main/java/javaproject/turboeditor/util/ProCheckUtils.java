package javaproject.turboeditor.util;

import android.content.Context;

public class ProCheckUtils {
    public static boolean isPro(Context context, boolean includeDonations) {

        // happy new year
        return context.getPackageName().equals("com.maskyn.fileeditorpro");

    }

    public static boolean isPro(Context context) {
        return isPro(context, true);
    }
}
