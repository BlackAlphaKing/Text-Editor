package com.javaproject.fileeditor;

import android.os.Bundle;

import com.crashlytics.android.Crashlytics;

import io.fabric.sdk.android.Fabric;
import javaproject.turboeditor.preferences.PreferenceHelper;
import javaproject.turboeditor.activity.MainActivity;
import javaproject.turboeditor.util.ProCheckUtils;

public class HomeActivity extends MainActivity {

    private AdsHelper adsHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(PreferenceHelper.getSendErrorReports(this))
            Fabric.with(this, new Crashlytics());
        if(!ProCheckUtils.isPro(this))
            adsHelper = new AdsHelper(this);
    }

    @Override
    public boolean showInterstitial() {
        if(adsHelper != null && !ProCheckUtils.isPro(this)) {
            adsHelper.displayInterstitial();
            return true;
        }
        else {
            return false;
        }
    }


}
