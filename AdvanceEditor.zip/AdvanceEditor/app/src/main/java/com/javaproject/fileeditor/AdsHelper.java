package com.javaproject.fileeditor;

import android.app.Activity;

public class AdsHelper {

    public AdsHelper(Activity activity) {


    }

    public void displayInterstitial() {
        //interstitial.show();
    }
}
