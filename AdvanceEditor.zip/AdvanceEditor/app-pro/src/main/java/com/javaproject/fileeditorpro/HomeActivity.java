package com.javaproject.fileeditorpro;

import javaproject.turboeditor.activity.MainActivity;

public class HomeActivity extends MainActivity {

    @Override
    public boolean showInterstitial() {
        // nothing to do here
        return false;
    }
}
